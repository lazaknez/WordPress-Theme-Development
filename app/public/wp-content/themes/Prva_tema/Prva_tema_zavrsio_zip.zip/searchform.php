<form  action="<?php echo home_url() ?>" method="get">

  <input type="search" name="s" placeholder="Pretražite ovde..." value="<?php echo get_search_query(); ?>">
  <input type="submit" id="search-btn" value="">

</form>
