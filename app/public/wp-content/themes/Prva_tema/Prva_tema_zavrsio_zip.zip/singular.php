<?php include 'header.php';?>


<h2>singular.php</h2>


<?php include 'footer.php';?>
